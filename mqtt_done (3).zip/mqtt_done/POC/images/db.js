var mysql = require('mysql');
var connection = mysql.createConnection({
 host:'localhost',
 user:'root',
 password:'1234',
 database:'poc'
});
connection.connect(function(error){
 if(!!error) {
  console.log(error);
 } else {
  console.log('Database Connected Successfully..!!');
 }
});

module.exports = connection;