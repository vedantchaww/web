CREATE DATABASE IF NOT EXISTS poc;
USE poc;

-- Drop the 'users' table if it exists
DROP TABLE IF EXISTS users;

-- Create 'users' table
CREATE TABLE users (
  id INT(50) AUTO_INCREMENT PRIMARY KEY NOT NULL,
  name VARCHAR(100) DEFAULT NULL,
  email VARCHAR(100) DEFAULT NULL,
  password VARCHAR(100) DEFAULT NULL,
  position VARCHAR(100) DEFAULT NULL
);

-- Set MySQL root user password
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '1234';

-- Insert initial admin user
INSERT INTO users (id, name, email, password, position) 
VALUES (1, 'admin', 'admin', 'admin', 'admin');

-- Select all users
SELECT * FROM users;

-- Drop the 'reports' table if it exists
DROP TABLE IF EXISTS reports;

-- Create 'reports' table with new fields
CREATE TABLE reports (
  id INT AUTO_INCREMENT PRIMARY KEY, -- Added primary key for the reports table
  plant VARCHAR(255),
  line VARCHAR(255),
  crop VARCHAR(255),
  variety VARCHAR(255),
  sku VARCHAR(255),
  nicchrome_io_no VARCHAR(255),
  shift_start DATETIME,
  shift_end DATETIME,
  total_time INT,
  hybrid_time INT,
  lot_time INT,
  laminate_time INT,
  printer_issue VARCHAR(255),
  machine_startup VARCHAR(255),
  secondary_packing VARCHAR(255),
  forklift_availability VARCHAR(255),
  pallet_availability VARCHAR(255),
  stitching_issue VARCHAR(255),
  power_failure VARCHAR(255),
  labour_arrival_delay VARCHAR(255),
  hamali_issue VARCHAR(255),
  house_keeping VARCHAR(255),
  seed_issue_delay VARCHAR(255),
  tool_box_meeting VARCHAR(255),
  machine_breakdown VARCHAR(255),
  qc_delays VARCHAR(255),
  lunch_break VARCHAR(255),
  miscellaneous VARCHAR(255)
);

-- Select all reports
SELECT * FROM reports;

-- Drop the 'issues' table if it exists
DROP TABLE IF EXISTS issues;

-- Create 'issues' table
CREATE TABLE issues (
  id INT AUTO_INCREMENT PRIMARY KEY, -- Added primary key for the issues table
  report_id INT, -- Foreign key to link to the reports table
  issue_type VARCHAR(255) NOT NULL, -- Type of issue (e.g., printer, machine startup, etc.)
  issue_details TEXT, -- Additional details about the issue
  timer_start TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- Time when the issue started
  timer_end TIMESTAMP NULL, -- Time when the issue ended
  duration INT NULL, -- Total duration in seconds, calculated when timer stops
  status ENUM('open', 'resolved') DEFAULT 'open', -- Status of the issue
  FOREIGN KEY (report_id) REFERENCES reports(id) ON DELETE CASCADE
);

-- Select all issues
SELECT * FROM issues;

-- Drop the 'mqtt_pac' table if it exists
DROP TABLE IF EXISTS mqtt_pac;

-- Create 'mqtt_pac' table
CREATE TABLE IF NOT EXISTS mqtt_pac (
  id INT AUTO_INCREMENT PRIMARY KEY,
  topic VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  received_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Select all data from mqtt_pac table
SELECT * FROM mqtt_pac;
